import { useState, useEffect } from 'react';
import { TaskType, CognitiveProfile, NBackResult, OSPANResult, ChangeDetectionResult } from './types/wm';
import { loadCognitiveProfile, saveNBackResult, saveOSPANResult, saveChangeDetectionResult, clearCognitiveHistory } from './utils/storage';
import { soundManager } from './utils/audio';
import { Header } from './components/Header';
import { AcademicTheoryModal } from './components/AcademicTheoryModal';
import { NBackTask } from './components/NBackTask';
import { OSPANTask } from './components/OSPANTask';
import { ChangeDetectionTask } from './components/ChangeDetectionTask';
import { CognitiveDashboard } from './components/CognitiveDashboard';
import { BookOpen, Brain, ShieldCheck, Download } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TaskType>('nback');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isTheoryOpen, setIsTheoryOpen] = useState<boolean>(false);
  const [profile, setProfile] = useState<CognitiveProfile>(() => loadCognitiveProfile());

  // Toggle sound
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundManager.isMuted = nextMuted;
    if (!nextMuted) {
      soundManager.playTick();
    }
  };

  // Result handlers
  const handleSaveNBack = (result: NBackResult) => {
    const updated = saveNBackResult(result);
    setProfile(updated);
  };

  const handleSaveOSPAN = (result: OSPANResult) => {
    const updated = saveOSPANResult(result);
    setProfile(updated);
  };

  const handleSaveChangeDetection = (result: ChangeDetectionResult) => {
    const updated = saveChangeDetectionResult(result);
    setProfile(updated);
  };

  const handleClearHistory = () => {
    const updated = clearCognitiveHistory();
    setProfile(updated);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Navigation Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenTheory={() => setIsTheoryOpen(true)}
      />

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'nback' && (
          <NBackTask onSaveResult={handleSaveNBack} />
        )}

        {activeTab === 'ospan' && (
          <OSPANTask onSaveResult={handleSaveOSPAN} />
        )}

        {activeTab === 'change_detection' && (
          <ChangeDetectionTask onSaveResult={handleSaveChangeDetection} />
        )}

        {activeTab === 'dashboard' && (
          <CognitiveDashboard
            profile={profile}
            onSelectTab={setActiveTab}
            onClearHistory={handleClearHistory}
          />
        )}
      </main>

      {/* Academic Citation Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-indigo-400" />
            <span>认知心理学 & 认知神经科学工作记忆经典实验范式平台</span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-[11px] text-slate-400 font-mono">
            <span>Kirchner (1958)</span>
            <span>·</span>
            <span>Turner & Engle (1989)</span>
            <span>·</span>
            <span>Cowan (2001)</span>
            <span>·</span>
            <span>Luck & Vogel (1997)</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              id="btn-footer-download-zip"
              href="/working-memory-training.zip"
              download="working-memory-training.zip"
              className="text-[11px] text-cyan-400 hover:text-cyan-300 underline underline-offset-2 flex items-center gap-1 cursor-pointer"
              title="下载项目完整源码 ZIP"
            >
              <Download className="w-3 h-3" />
              <span>下载项目源码 (ZIP)</span>
            </a>
            <button
              id="btn-footer-theory"
              onClick={() => setIsTheoryOpen(true)}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 underline underline-offset-2 flex items-center gap-1 cursor-pointer"
            >
              <BookOpen className="w-3 h-3" />
              <span>学术文献与公式详解</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Academic Paradigm Theory Modal */}
      <AcademicTheoryModal
        isOpen={isTheoryOpen}
        onClose={() => setIsTheoryOpen(false)}
      />
    </div>
  );
}
