import { NBackResult, OSPANResult, ChangeDetectionResult, CognitiveProfile } from '../types/wm';

const STORAGE_KEY = 'wm_cognitive_platform_data_v1';

export function loadCognitiveProfile(): CognitiveProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        lastNBackResult: null,
        lastOSPANResult: null,
        lastChangeDetectionResult: null,
        history: [],
      };
    }
    return JSON.parse(raw);
  } catch {
    return {
      lastNBackResult: null,
      lastOSPANResult: null,
      lastChangeDetectionResult: null,
      history: [],
    };
  }
}

export function saveNBackResult(result: NBackResult): CognitiveProfile {
  const profile = loadCognitiveProfile();
  profile.lastNBackResult = result;
  profile.history.unshift({
    id: `nback_${Date.now()}`,
    timestamp: Date.now(),
    type: 'nback',
    scoreDisplay: `${result.n}-back | 正确率: ${(result.accuracy * 100).toFixed(0)}% (d'=${result.dPrime})`,
    detail: `命中: ${result.hits}, 虚报: ${result.falseAlarms}, 平均反应时: ${Math.round(result.meanReactionTimeMs)}ms`,
  });
  if (profile.history.length > 30) profile.history.pop();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  return profile;
}

export function saveOSPANResult(result: OSPANResult): CognitiveProfile {
  const profile = loadCognitiveProfile();
  profile.lastOSPANResult = result;
  profile.history.unshift({
    id: `ospan_${Date.now()}`,
    timestamp: Date.now(),
    type: 'ospan',
    scoreDisplay: `绝对得分: ${result.absoluteScore} / ${result.maxPossibleScore} | 运算正确率: ${(result.mathAccuracy * 100).toFixed(0)}%`,
    detail: `总回忆正确项: ${result.totalScore}, 加工平均RT: ${Math.round(result.meanMathRT)}ms`,
  });
  if (profile.history.length > 30) profile.history.pop();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  return profile;
}

export function saveChangeDetectionResult(result: ChangeDetectionResult): CognitiveProfile {
  const profile = loadCognitiveProfile();
  profile.lastChangeDetectionResult = result;
  profile.history.unshift({
    id: `cd_${Date.now()}`,
    timestamp: Date.now(),
    type: 'change_detection',
    scoreDisplay: `Cowan's K = ${result.meanCowanK.toFixed(2)} | 准确率: ${(result.overallAccuracy * 100).toFixed(0)}%`,
    detail: `测试项阵列 4/6/8, 平均反应时: ${Math.round(result.meanReactionTimeMs)}ms`,
  });
  if (profile.history.length > 30) profile.history.pop();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  return profile;
}

export function clearCognitiveHistory(): CognitiveProfile {
  const blank: CognitiveProfile = {
    lastNBackResult: null,
    lastOSPANResult: null,
    lastChangeDetectionResult: null,
    history: [],
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(blank));
  return blank;
}
