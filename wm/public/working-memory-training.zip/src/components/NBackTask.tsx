import { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Play, RotateCcw, Award, CheckCircle2, XCircle, ArrowRight, Zap, Info, Settings2 } from 'lucide-react';
import { NBackConfig, NBackResult, NBackStimulusMode, NBackTrial } from '../types/wm';
import { calculateDPrime } from '../utils/statistics';
import { soundManager } from '../utils/audio';

interface NBackTaskProps {
  onSaveResult: (result: NBackResult) => void;
}

const LETTERS = ['A', 'B', 'C', 'D', 'H', 'J', 'K', 'M', 'Q', 'R', 'T', 'X'];
const SYMBOLS = ['◆', '▲', '●', '■', '★', '✚', '✦', '⬢'];

export const NBackTask = ({ onSaveResult }: NBackTaskProps) => {
  // Config state
  const [config, setConfig] = useState<NBackConfig>({
    n: 2,
    stimulusMode: 'spatial',
    totalTrials: 20,
    stimulusDuration: 600,
    isiDuration: 1400,
    targetRatio: 0.35,
  });

  // Task execution states
  // 'idle' | 'countdown' | 'running' | 'completed'
  const [taskState, setTaskState] = useState<'idle' | 'countdown' | 'running' | 'completed'>('idle');
  const [countdown, setCountdown] = useState<number>(3);
  const [currentTrialIdx, setCurrentTrialIdx] = useState<number>(0);
  const [currentStimulus, setCurrentStimulus] = useState<string | number | null>(null);
  const [isStimulusVisible, setIsStimulusVisible] = useState<boolean>(false);
  const [trialFeedbacks, setTrialFeedbacks] = useState<{ [key: number]: 'hit' | 'miss' | 'fa' | 'cr' }>({});
  const [lastActionFeedback, setLastActionFeedback] = useState<string | null>(null);

  // Buffer and records
  const trialsRef = useRef<NBackTrial[]>([]);
  const currentTrialStartTime = useRef<number>(0);
  const respondedInCurrentTrial = useRef<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Result state
  const [finalResult, setFinalResult] = useState<NBackResult | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  // Pre-generate trial sequence
  const generateTrialSequence = useCallback(() => {
    const total = config.totalTrials;
    const n = config.n;
    const targetCount = Math.round((total - n) * config.targetRatio);

    // Target positions in trials (index >= n)
    const possibleTargetIndices: number[] = [];
    for (let i = n; i < total; i++) {
      possibleTargetIndices.push(i);
    }
    // Shuffle and pick target indices
    const targetIndices = new Set<number>();
    const shuffled = [...possibleTargetIndices].sort(() => Math.random() - 0.5);
    for (let i = 0; i < Math.min(targetCount, shuffled.length); i++) {
      targetIndices.add(shuffled[i]);
    }

    const sequence: (string | number)[] = [];
    for (let i = 0; i < total; i++) {
      if (targetIndices.has(i)) {
        // Target: must equal the stimulus at i - n
        sequence.push(sequence[i - n]);
      } else {
        // Non-target: pick randomly ensuring it does NOT equal sequence[i - n] (if i >= n)
        let candidate: string | number;
        do {
          if (config.stimulusMode === 'spatial') {
            candidate = Math.floor(Math.random() * 9); // 0-8 for 3x3 grid
          } else if (config.stimulusMode === 'letter') {
            candidate = LETTERS[Math.floor(Math.random() * LETTERS.length)];
          } else {
            candidate = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
          }
        } while (i >= n && candidate === sequence[i - n]);
        sequence.push(candidate);
      }
    }

    const trials: NBackTrial[] = sequence.map((stim, idx) => ({
      trialIndex: idx,
      stimulus: stim,
      isTarget: idx >= n && stim === sequence[idx - n],
      userResponded: false,
      userSaidMatch: false,
      responseTimeMs: null,
      result: 'correct_rejection',
    }));

    trialsRef.current = trials;
  }, [config]);

  // Start countdown
  const startTask = () => {
    generateTrialSequence();
    setTaskState('countdown');
    setCountdown(3);
    setTrialFeedbacks({});
    setLastActionFeedback(null);
    setFinalResult(null);

    let count = 3;
    soundManager.playTick();
    const interval = setInterval(() => {
      count -= 1;
      if (count > 0) {
        setCountdown(count);
        soundManager.playTick();
      } else {
        clearInterval(interval);
        setTaskState('running');
        runTrial(0);
      }
    }, 900);
  };

  // Run individual trial
  const runTrial = (trialIndex: number) => {
    if (trialIndex >= config.totalTrials) {
      finishTask();
      return;
    }

    setCurrentTrialIdx(trialIndex);
    const trial = trialsRef.current[trialIndex];
    setCurrentStimulus(trial.stimulus);
    setIsStimulusVisible(true);
    respondedInCurrentTrial.current = false;
    currentTrialStartTime.current = performance.now();
    soundManager.playStimulusOnset();

    // Stimulus display timer
    timerRef.current = setTimeout(() => {
      setIsStimulusVisible(false);

      // ISI duration timer (inter-stimulus interval)
      timerRef.current = setTimeout(() => {
        // If trial ended and user didn't respond
        evaluateTrialEnd(trialIndex);
        runTrial(trialIndex + 1);
      }, config.isiDuration);
    }, config.stimulusDuration);
  };

  // Evaluate when trial finishes without response or with response
  const evaluateTrialEnd = (trialIdx: number) => {
    const trial = trialsRef.current[trialIdx];
    if (!trial.userResponded) {
      if (trial.isTarget) {
        trial.result = 'miss';
        setTrialFeedbacks((prev) => ({ ...prev, [trialIdx]: 'miss' }));
      } else {
        trial.result = 'correct_rejection';
        setTrialFeedbacks((prev) => ({ ...prev, [trialIdx]: 'cr' }));
      }
    }
  };

  // User press match
  const handleUserMatch = useCallback(() => {
    if (taskState !== 'running' || respondedInCurrentTrial.current) return;

    const trialIdx = currentTrialIdx;
    const trial = trialsRef.current[trialIdx];
    if (!trial) return;

    respondedInCurrentTrial.current = true;
    trial.userResponded = true;
    trial.userSaidMatch = true;
    trial.responseTimeMs = performance.now() - currentTrialStartTime.current;

    if (trial.isTarget) {
      trial.result = 'hit';
      setTrialFeedbacks((prev) => ({ ...prev, [trialIdx]: 'hit' }));
      setLastActionFeedback('✓ 匹配成功 (Hit)');
      soundManager.playSuccess();
    } else {
      trial.result = 'false_alarm';
      setTrialFeedbacks((prev) => ({ ...prev, [trialIdx]: 'fa' }));
      setLastActionFeedback('✗ 误报 (False Alarm)');
      soundManager.playError();
    }
  }, [taskState, currentTrialIdx]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'KeyJ') {
        e.preventDefault();
        handleUserMatch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUserMatch]);

  // Finish task and compute statistics
  const finishTask = () => {
    setTaskState('completed');
    setCurrentStimulus(null);
    setIsStimulusVisible(false);

    const allTrials = trialsRef.current;
    const evaluatedTrials = allTrials.slice(config.n); // Only trials after N are evaluation targets

    let hits = 0;
    let misses = 0;
    let falseAlarms = 0;
    let correctRejections = 0;
    let totalRT = 0;
    let rtCount = 0;

    evaluatedTrials.forEach((t) => {
      if (t.isTarget) {
        if (t.result === 'hit') {
          hits++;
          if (t.responseTimeMs) {
            totalRT += t.responseTimeMs;
            rtCount++;
          }
        } else {
          misses++;
        }
      } else {
        if (t.result === 'false_alarm') {
          falseAlarms++;
        } else {
          correctRejections++;
        }
      }
    });

    const targetCount = hits + misses;
    const nonTargetCount = falseAlarms + correctRejections;
    const accuracy = evaluatedTrials.length > 0 ? (hits + correctRejections) / evaluatedTrials.length : 0;
    const dPrime = calculateDPrime(hits, targetCount, falseAlarms, nonTargetCount);
    const meanReactionTimeMs = rtCount > 0 ? totalRT / rtCount : 0;

    const resultData: NBackResult = {
      date: new Date().toLocaleDateString('zh-CN'),
      n: config.n,
      mode: config.stimulusMode,
      totalTrials: config.totalTrials,
      hits,
      misses,
      falseAlarms,
      correctRejections,
      accuracy,
      dPrime,
      meanReactionTimeMs,
    };

    setFinalResult(resultData);
    onSaveResult(resultData);
    soundManager.playComplete();

    // Trigger celebration if accuracy is good
    if (accuracy >= 0.75) {
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } catch {}
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Paradigm Intro Header */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 sm:p-6 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                范式 1 · 动态更新与抑制控制
              </span>
              <span className="text-xs text-slate-400 font-mono">Kirchner (1958)</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1.5 tracking-tight">N-back 任务训练与评估</h2>
            <p className="text-xs text-slate-400 mt-1">
              要求在不断推移的信息流中，判断当前刺激是否与倒数第 <strong>{config.n}</strong> 步的刺激一致。用于评估背外侧前额叶皮层 (DLPFC) 的持续动态刷新能力。
            </p>
          </div>

          {taskState === 'idle' && (
            <button
              id="btn-start-nback"
              onClick={startTask}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition shadow-lg shadow-indigo-600/25 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>开始评估/训练</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Task Area */}
      {taskState === 'idle' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Config panel */}
          <div className="md:col-span-1 bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-200 border-b border-slate-800 pb-2">
              <Settings2 className="w-4 h-4 text-indigo-400" />
              <span>参数调节与测试难度</span>
            </div>

            {/* N-back level selector */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">N-back 步长级别 (N)</label>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3].map((num) => (
                  <button
                    key={num}
                    id={`btn-nback-select-${num}`}
                    onClick={() => setConfig((prev) => ({ ...prev, n: num }))}
                    className={`py-2 text-xs font-semibold rounded-xl border transition ${
                      config.n === num
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {num}-Back
                    <span className="block text-[10px] font-normal opacity-75">
                      {num === 1 ? '基础入门' : num === 2 ? '经典评估' : '高阶挑战'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Stimulus Mode */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">刺激类型 (Stimulus Mode)</label>
              <div className="grid grid-cols-3 gap-2">
                {(['spatial', 'letter', 'symbol'] as NBackStimulusMode[]).map((mode) => (
                  <button
                    key={mode}
                    id={`btn-nback-mode-${mode}`}
                    onClick={() => setConfig((prev) => ({ ...prev, stimulusMode: mode }))}
                    className={`py-2 text-xs rounded-xl border transition ${
                      config.stimulusMode === mode
                        ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-semibold'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode === 'spatial' ? '九宫格空间' : mode === 'letter' ? '字母序列' : '几何图形'}
                  </button>
                ))}
              </div>
            </div>

            {/* Trials count */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">试次数目 (Trials)</label>
              <div className="grid grid-cols-3 gap-2">
                {[15, 25, 40].map((count) => (
                  <button
                    key={count}
                    id={`btn-nback-trials-${count}`}
                    onClick={() => setConfig((prev) => ({ ...prev, totalTrials: count }))}
                    className={`py-1.5 text-xs rounded-xl border transition ${
                      config.totalTrials === count
                        ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-semibold'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {count} 次
                  </button>
                ))}
              </div>
            </div>

            {/* Scientific hint box */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 text-indigo-400 font-semibold">
                <Info className="w-3.5 h-3.5" />
                <span>操作指南</span>
              </div>
              <p>
                观察中央刺激，若当前刺激与 <strong>{config.n} 步之前</strong> 出现的刺激完全相同，请立即按下 <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">空格键</kbd> 或点击【匹配】。
              </p>
            </div>
          </div>

          {/* Interactive Preview Canvas */}
          <div className="md:col-span-2 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[340px] text-center">
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4">
              <Zap className="w-8 h-8" />
            </div>
            <h3 className="text-base font-semibold text-white">已就绪：{config.n}-Back {config.stimulusMode === 'spatial' ? '空间' : config.stimulusMode === 'letter' ? '字母' : '图形'}训练</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1.5 leading-relaxed">
              共 {config.totalTrials} 组刺激，单次刺激呈现 {config.stimulusDuration}ms，间隔 {config.isiDuration}ms。准备好你的工作记忆缓存！
            </p>
            <button
              id="btn-preview-start"
              onClick={startTask}
              className="mt-6 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition shadow-lg shadow-indigo-600/20"
            >
              立刻开始实验
            </button>
          </div>
        </div>
      )}

      {/* Countdown View */}
      {taskState === 'countdown' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-12 flex flex-col items-center justify-center min-h-[380px] text-center">
          <div className="text-xs font-semibold text-indigo-400 uppercase tracking-widest mb-3">
            {config.n}-Back 即将呈现
          </div>
          <div className="w-24 h-24 rounded-full bg-indigo-500/20 border-2 border-indigo-500 flex items-center justify-center text-5xl font-bold text-white shadow-xl shadow-indigo-500/20 animate-pulse">
            {countdown}
          </div>
          <p className="text-xs text-slate-400 mt-6">
            保持注意力高度集中，注视屏幕中央
          </p>
        </div>
      )}

      {/* Running Trial View */}
      {taskState === 'running' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 flex flex-col items-center min-h-[460px]">
          {/* Top trial status bar */}
          <div className="w-full flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-3 mb-6">
            <div className="flex items-center gap-3">
              <span className="font-semibold text-indigo-300">
                试次: {currentTrialIdx + 1} / {config.totalTrials}
              </span>
              <span className="text-slate-500">|</span>
              <span>步长: {config.n}-Back</span>
            </div>
            <div>
              {lastActionFeedback && (
                <span className="text-xs font-medium text-indigo-400 animate-fade-in">
                  {lastActionFeedback}
                </span>
              )}
            </div>
          </div>

          {/* Stimulus display center */}
          <div className="flex-1 flex items-center justify-center w-full my-4">
            {config.stimulusMode === 'spatial' ? (
              /* 3x3 Spatial Grid */
              <div className="grid grid-cols-3 gap-3 p-4 bg-slate-950 rounded-2xl border border-slate-800 shadow-inner">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((cellIdx) => {
                  const isActive = isStimulusVisible && currentStimulus === cellIdx;
                  return (
                    <div
                      key={cellIdx}
                      className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl border transition-all duration-150 flex items-center justify-center ${
                        isActive
                          ? 'bg-indigo-500 border-indigo-300 shadow-lg shadow-indigo-500/50 scale-105'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      {isActive && <div className="w-4 h-4 rounded-full bg-white shadow-sm" />}
                    </div>
                  );
                })}
              </div>
            ) : (
              /* Character or Symbol Stimulus */
              <div className="w-48 h-48 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-inner">
                {isStimulusVisible && (
                  <span className="text-6xl font-bold font-mono text-indigo-300 tracking-wider transition-all scale-110">
                    {currentStimulus}
                  </span>
                )}
                {!isStimulusVisible && (
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700 animate-pulse" />
                )}
              </div>
            )}
          </div>

          {/* Interactive Response Controls */}
          <div className="w-full max-w-md mt-6 space-y-3">
            <button
              id="btn-nback-respond-match"
              onClick={handleUserMatch}
              disabled={respondedInCurrentTrial.current}
              className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
                respondedInCurrentTrial.current
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 active:scale-[0.98]'
              }`}
            >
              <span>匹配！与前第 {config.n} 步相同</span>
              <kbd className="hidden sm:inline-block text-[11px] px-2 py-0.5 rounded bg-indigo-700/80 border border-indigo-400/30 text-white">
                Space 或 J
              </kbd>
            </button>
            <p className="text-[11px] text-center text-slate-400">
              若不同无需按键，刺激将在 {config.stimulusDuration + config.isiDuration}ms 后自动推进
            </p>
          </div>
        </div>
      )}

      {/* Completed Results View */}
      {taskState === 'completed' && finalResult && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">
                  {finalResult.n}-Back 动态更新任务评估结果
                </h3>
                <p className="text-xs text-slate-400">
                  前额叶皮层执行功能与信号检测论分析
                </p>
              </div>
            </div>
            <button
              id="btn-nback-restart"
              onClick={startTask}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-medium border border-slate-700 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>重新测试</span>
            </button>
          </div>

          {/* Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-1">信号敏感度 (d')</span>
              <span className="text-2xl font-bold font-mono text-indigo-400">{finalResult.dPrime}</span>
              <span className="text-[10px] text-slate-400 block mt-1">
                {finalResult.dPrime >= 2.5 ? '极高判别力' : finalResult.dPrime >= 1.5 ? '良好辨别力' : '一般/需提升'}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-1">综合正确率</span>
              <span className="text-2xl font-bold font-mono text-emerald-400">
                {(finalResult.accuracy * 100).toFixed(0)}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">
                含命中与正确拒绝
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-1">平均反应时</span>
              <span className="text-2xl font-bold font-mono text-cyan-400">
                {Math.round(finalResult.meanReactionTimeMs)}
                <span className="text-xs text-slate-400 ml-1">ms</span>
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">命中决策延迟</span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-1">抑制失误 (虚报)</span>
              <span className="text-2xl font-bold font-mono text-amber-400">{finalResult.falseAlarms}</span>
              <span className="text-[10px] text-slate-400 block mt-1">
                冲动抑制控制指标
              </span>
            </div>
          </div>

          {/* Detailed breakdown table */}
          <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 text-xs space-y-3">
            <h4 className="font-semibold text-slate-200">信号检测论详细分布：</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-500/20">
                <span className="text-emerald-400 block font-bold text-base">{finalResult.hits}</span>
                <span className="text-slate-400 text-[11px]">命中 (Hit)</span>
              </div>
              <div className="p-2.5 rounded-lg bg-rose-950/20 border border-rose-500/20">
                <span className="text-rose-400 block font-bold text-base">{finalResult.misses}</span>
                <span className="text-slate-400 text-[11px]">漏报 (Miss)</span>
              </div>
              <div className="p-2.5 rounded-lg bg-amber-950/20 border border-amber-500/20">
                <span className="text-amber-400 block font-bold text-base">{finalResult.falseAlarms}</span>
                <span className="text-slate-400 text-[11px]">虚报 (False Alarm)</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-300 block font-bold text-base">{finalResult.correctRejections}</span>
                <span className="text-slate-400 text-[11px]">正确拒绝 (CR)</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              id="btn-nback-return-idle"
              onClick={() => setTaskState('idle')}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
            >
              完成并返回配置
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
