import { Brain, Award, BarChart3, Clock, Sparkles, CheckCircle2, RotateCcw, Trash2, ArrowRight } from 'lucide-react';
import { CognitiveProfile, TaskType } from '../types/wm';
import { RadarChart } from './RadarChart';

interface CognitiveDashboardProps {
  profile: CognitiveProfile;
  onSelectTab: (tab: TaskType) => void;
  onClearHistory: () => void;
}

export const CognitiveDashboard = ({
  profile,
  onSelectTab,
  onClearHistory,
}: CognitiveDashboardProps) => {
  // Normalize metrics into 0-100 scale for the 5 cognitive dimensions
  // 1. Updating (N-back)
  let updatingScore = 65; // default benchmark
  if (profile.lastNBackResult) {
    const d = profile.lastNBackResult.dPrime;
    // d' typically -0.5 to 3.5. Map 0 -> 40, 2.0 -> 80, 3.0 -> 95
    updatingScore = Math.min(100, Math.max(20, Math.round(40 + d * 20)));
  }

  // 2. Complex Span (OSPAN)
  let spanScore = 65;
  if (profile.lastOSPANResult) {
    const ratio = profile.lastOSPANResult.totalScore / profile.lastOSPANResult.maxPossibleScore;
    spanScore = Math.min(100, Math.max(25, Math.round(ratio * 100)));
  }

  // 3. Visuospatial Capacity (Cowan's K)
  let capacityScore = 65;
  if (profile.lastChangeDetectionResult) {
    const k = profile.lastChangeDetectionResult.meanCowanK;
    // K typically 1.5 to 4.5. Map 3.0 -> 75, 4.0 -> 92
    capacityScore = Math.min(100, Math.max(20, Math.round((k / 4.2) * 100)));
  }

  // 4. Processing Speed (based on reaction times)
  let speedScore = 70;
  const rts: number[] = [];
  if (profile.lastNBackResult?.meanReactionTimeMs) rts.push(profile.lastNBackResult.meanReactionTimeMs);
  if (profile.lastChangeDetectionResult?.meanReactionTimeMs) rts.push(profile.lastChangeDetectionResult.meanReactionTimeMs);
  if (rts.length > 0) {
    const avgRT = rts.reduce((a, b) => a + b, 0) / rts.length;
    // Faster is better: 300ms -> 95, 600ms -> 75, 1000ms -> 50
    speedScore = Math.min(100, Math.max(30, Math.round(110 - (avgRT / 1000) * 50)));
  }

  // 5. Inhibition Control (low false alarms)
  let inhibitionScore = 75;
  if (profile.lastNBackResult) {
    const fa = profile.lastNBackResult.falseAlarms;
    inhibitionScore = Math.max(35, Math.min(100, 95 - fa * 8));
  }

  const radarAxes = [
    { label: '动态刷新力', value: updatingScore },
    { label: '复杂加工跨度', value: spanScore },
    { label: '视空间容量', value: capacityScore },
    { label: '加工响应敏捷度', value: speedScore },
    { label: '抗干扰抑制控制', value: inhibitionScore },
  ];

  // Composite working memory score
  const compositeScore = Math.round(
    (updatingScore + spanScore + capacityScore + speedScore + inhibitionScore) / 5
  );

  const completedCount =
    (profile.lastNBackResult ? 1 : 0) +
    (profile.lastOSPANResult ? 1 : 0) +
    (profile.lastChangeDetectionResult ? 1 : 0);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white tracking-tight">个人工作记忆综合画像与测评总览</h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  综合指数 {compositeScore}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                已完成三大范式中的 {completedCount} / 3 项评测 · 动态雷达维度模型
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {profile.history.length > 0 && (
              <button
                id="btn-clear-wm-history"
                onClick={onClearHistory}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-rose-400 text-xs font-medium border border-slate-700/60 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>清除记录</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Radar & Composite Score Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Radar Chart Card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[360px]">
          <h3 className="text-sm font-semibold text-slate-200 self-start flex items-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <span>五维工作记忆认知雷达</span>
          </h3>
          <div className="py-2">
            <RadarChart axes={radarAxes} size={280} />
          </div>
          <p className="text-[11px] text-slate-400 text-center mt-1">
            由 N-back (更新/抑制)、OSPAN (双任务跨度)、视觉变化检测 (K值) 联合拟合
          </p>
        </div>

        {/* Cognitive Index & Recommendations Card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>神经认知评估与学术建议</span>
            </h3>

            {/* Qualitative summary */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 text-xs text-slate-300">
              <p className="leading-relaxed">
                {compositeScore >= 85 ? (
                  <strong className="text-emerald-400 font-bold block mb-1">
                    🌟 卓越级认知水平 (Top 10% 顶尖容量)
                  </strong>
                ) : compositeScore >= 70 ? (
                  <strong className="text-sky-400 font-bold block mb-1">
                    ✨ 优秀/健康常模水平 (High Average)
                  </strong>
                ) : (
                  <strong className="text-amber-400 font-bold block mb-1">
                    ⚡ 具备极大可塑性提升空间 (High Plasticity)
                  </strong>
                )}
                工作记忆并非固定不变的先天智力，而是受前额叶皮层突触强化驱动的高度动态系统。
              </p>

              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                <p>
                  • <strong>动态刷新专项：</strong>每日坚持 10 分钟 2-back 或 3-back 空间训练，强力激活背外侧前额叶皮层 (DLPFC)。
                </p>
                <p>
                  • <strong>抗干扰与双任务：</strong>进行 OSPAN 练习以抵抗阅读/编码等深层心流下的瞬时干扰中断。
                </p>
                <p>
                  • <strong>视空间扩容：</strong>在变化检测中训练多客体整体感知与特征绑定（Chunking 组块策略）。
                </p>
              </div>
            </div>
          </div>

          {/* Quick launch paradigm tiles */}
          <div className="space-y-2">
            <span className="text-xs text-slate-400 font-medium">快速进入指定专项范式：</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                id="btn-dash-jump-nback"
                onClick={() => onSelectTab('nback')}
                className="p-2.5 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer"
              >
                <span>N-back</span>
                <ArrowRight className="w-3 h-3" />
              </button>
              <button
                id="btn-dash-jump-ospan"
                onClick={() => onSelectTab('ospan')}
                className="p-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer"
              >
                <span>OSPAN</span>
                <ArrowRight className="w-3 h-3" />
              </button>
              <button
                id="btn-dash-jump-cd"
                onClick={() => onSelectTab('change_detection')}
                className="p-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer"
              >
                <span>视觉K值</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Paradigm Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* N-back card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-400">N-back 动态刷新</span>
            <span className="text-[10px] text-slate-400 font-mono">Kirchner (1958)</span>
          </div>
          {profile.lastNBackResult ? (
            <div className="space-y-1">
              <div className="text-2xl font-bold font-mono text-white">
                d' = {profile.lastNBackResult.dPrime}
              </div>
              <div className="text-xs text-slate-400">
                正确率 {(profile.lastNBackResult.accuracy * 100).toFixed(0)}% · {profile.lastNBackResult.n}-back
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400 py-3">暂无测试数据，点击进入开始首次测评</div>
          )}
          <button
            id="btn-card-goto-nback"
            onClick={() => onSelectTab('nback')}
            className="w-full py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 text-xs font-medium border border-indigo-500/30 transition cursor-pointer"
          >
            {profile.lastNBackResult ? '再测一次' : '立即评测'}
          </button>
        </div>

        {/* OSPAN card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-cyan-400">OSPAN 运算跨度</span>
            <span className="text-[10px] text-slate-400 font-mono">Turner & Engle (1989)</span>
          </div>
          {profile.lastOSPANResult ? (
            <div className="space-y-1">
              <div className="text-2xl font-bold font-mono text-white">
                {profile.lastOSPANResult.absoluteScore}
                <span className="text-xs text-slate-400 font-normal ml-1">/ {profile.lastOSPANResult.maxPossibleScore} 分</span>
              </div>
              <div className="text-xs text-slate-400">
                算术正确率 {(profile.lastOSPANResult.mathAccuracy * 100).toFixed(0)}%
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400 py-3">暂无测试数据，点击进入开始双任务评测</div>
          )}
          <button
            id="btn-card-goto-ospan"
            onClick={() => onSelectTab('ospan')}
            className="w-full py-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 text-xs font-medium border border-cyan-500/30 transition cursor-pointer"
          >
            {profile.lastOSPANResult ? '再测一次' : '立即评测'}
          </button>
        </div>

        {/* Change detection card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-400">视觉变化检测 (K值)</span>
            <span className="text-[10px] text-slate-400 font-mono">Cowan (2001)</span>
          </div>
          {profile.lastChangeDetectionResult ? (
            <div className="space-y-1">
              <div className="text-2xl font-bold font-mono text-white">
                K = {profile.lastChangeDetectionResult.meanCowanK.toFixed(2)}
              </div>
              <div className="text-xs text-slate-400">
                辨别率 {(profile.lastChangeDetectionResult.overallAccuracy * 100).toFixed(0)}% · 常模 3.0~4.5
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400 py-3">暂无测试数据，点击测定视觉离散槽位上限</div>
          )}
          <button
            id="btn-card-goto-cd"
            onClick={() => onSelectTab('change_detection')}
            className="w-full py-1.5 rounded-lg bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 text-xs font-medium border border-amber-500/30 transition cursor-pointer"
          >
            {profile.lastChangeDetectionResult ? '再测一次' : '立即评测'}
          </button>
        </div>
      </div>

      {/* History log */}
      {profile.history.length > 0 && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>历次训练与评测日志 (最近 {profile.history.length} 轮)</span>
            </h3>
          </div>

          <div className="divide-y divide-slate-800/60">
            {profile.history.map((record) => (
              <div key={record.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                <div className="flex items-center gap-2.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      record.type === 'nback'
                        ? 'bg-indigo-400'
                        : record.type === 'ospan'
                        ? 'bg-cyan-400'
                        : 'bg-amber-400'
                    }`}
                  />
                  <span className="font-semibold text-slate-200">{record.scoreDisplay}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-400">
                  <span className="text-[11px]">{record.detail}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(record.timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
